package pl.wsb.zpam.laboratorium2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.View;
import android.view.View.OnClickListener;

public class activity_info extends AppCompatActivity {

    private ImageButton logo;
    private int counter = 1;

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putInt("counter", counter);
        super.onSaveInstanceState(savedInstanceState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        if (savedInstanceState != null){
            counter = savedInstanceState.getInt("counter");
        }

        addListenerOnButton();
    }

    public void addListenerOnButton() {

        logo = (ImageButton) findViewById(R.id.imgLogo);

        logo.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                if (counter == 5) {
                    Toast.makeText(activity_info.this, "Jesteś blisko odkrycia prawdy…", Toast.LENGTH_SHORT).show();
                    counter = counter +1;
                } else if (counter == 6) {
                    Toast.makeText(activity_info.this, "Ciepło… ciepło…", Toast.LENGTH_SHORT).show();
                    counter = counter +1;
                } else if (counter == 7) {
                    Toast.makeText(activity_info.this, "Brawo! Odkryłeś ukrytą funkcję!", Toast.LENGTH_SHORT).show();
                    counter = counter +1;
                } else if (counter == 8) {
                    String url = "http://www.https://www.wsb.pl/";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
                else
                {
                    counter = counter +1;
                }

            }

        });
    }
}
