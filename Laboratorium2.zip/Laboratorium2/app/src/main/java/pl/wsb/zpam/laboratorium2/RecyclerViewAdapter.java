package pl.wsb.zpam.laboratorium2;


import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Toast;


import androidx.annotation.NonNull;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
;


public class RecyclerViewAdapter extends RecyclerView.Adapter<MyHolder> {

    Context c;
    ArrayList<Subject> subjects;
    ArrayList<Subject> checkedSub = new ArrayList<>();


    public RecyclerViewAdapter(Context c, ArrayList<Subject> subjects) {
        this.c = c;
        this.subjects = subjects;

    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int position) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, null);
        MyHolder holder = new MyHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        holder.txtSub.setText(subjects.get(position).getSubject());
        holder.txtName.setText(subjects.get(position).getName());

        holder.setItemClickListener(new OnListItemClick() {
            @Override
            public void onItemClick(View v, int pos) {
                CheckBox chk = (CheckBox) v;

                if (chk.isChecked()) {
                    checkedSub.add(subjects.get(pos));
                    Toast.makeText(c, "Dodano do ulubionych", Toast.LENGTH_SHORT).show();
                } else if (!chk.isChecked()) {
                    checkedSub.remove(subjects.get(pos));
                    Toast.makeText(c, "Usunięto z ulubionych", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return subjects.size();
    }
}