package pl.wsb.zpam.laboratorium2;

import android.view.View;

public interface OnListItemClick {

    void onItemClick(View v, int pos);
}
