package pl.wsb.zpam.laboratorium2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button info;
    private Button tel;
    private Button www;
    private Button list;
    private Button ex1;
    private Button ex2;
    private Button ex3;
    private Button ex4;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        info = (Button)findViewById(R.id.btnInfo);
        tel = (Button)findViewById(R.id.btnTel);
        www = (Button)findViewById(R.id.btnWWW);
        list = (Button)findViewById(R.id.btnList);
        ex1 = (Button) findViewById(R.id.btnEx1);
        ex2 = (Button) findViewById(R.id.btnEx2);
        ex3 = (Button) findViewById(R.id.btnEx3);
        ex4 = (Button) findViewById(R.id.btnEx4);

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, activity_info.class));
            }
        });

        tel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, activity_tel.class));
            }
        });

        www.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, activity_WWW.class));
            }
        });

        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, activity_List.class));
            }
        });



    }
    public void onBtnEx1Clicked (View view){
        Intent intent = new Intent(this, activity_extra.class);
        intent.putExtra("int", 1);
        intent.putExtra("str", "Extra1");
        intent.putExtra("float", 1.1f);
        intent.putExtra("bool", true);

        startActivity(intent);
    }

    public void onBtnEx2Clicked (View view){
        Intent intent = new Intent(this, activity_extra.class);
        intent.putExtra("int", 2);
        intent.putExtra("str", "Extra2");
        intent.putExtra("float", 2.2f);
        intent.putExtra("bool", false);

        startActivity(intent);
    }

    public void onBtnEx3Clicked (View view){
        Intent intent = new Intent(this, activity_extra.class);
        intent.putExtra("int", 3);
        intent.putExtra("str", "Extra3");
        intent.putExtra("float", 3.3f);
        intent.putExtra("bool", true);

        startActivity(intent);
    }

    public void onBtnEx4Clicked (View view){
        Intent intent = new Intent(this, activity_extra.class);
        intent.putExtra("int", 4);
        intent.putExtra("str", "Extra4");
        intent.putExtra("float", 4.4f);
        intent.putExtra("bool", false);

        startActivity(intent);
    }
}
