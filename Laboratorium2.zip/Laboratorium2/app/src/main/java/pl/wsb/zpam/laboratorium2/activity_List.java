package pl.wsb.zpam.laboratorium2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;


import java.util.ArrayList;


public class activity_List extends AppCompatActivity {

    RecyclerViewAdapter adapter;
    private RecyclerView mRecyclerView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__list);

        OnListItemClick onListItemClick = new OnListItemClick() {
            @Override
            public void onItemClick(View v, int pos) {
                CheckBox chk = (CheckBox) v;

                if (chk.isChecked()) {
                    Toast.makeText(activity_List.this, "Dodano do ulubionych", Toast.LENGTH_SHORT).show();
                } else if (!chk.isChecked()) {
                    Toast.makeText(activity_List.this, "Usunieto z ulubionych", Toast.LENGTH_SHORT).show();
                }
            }
        };

        adapter = new RecyclerViewAdapter(this,getSubjects());


        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mRecyclerView.setAdapter(adapter);
    }

    private ArrayList<Subject> getSubjects() {
        ArrayList<Subject> subjects = new ArrayList<>();
        Subject s = new Subject("Inżynieria Oprogramowania", "dr inż. Mariusz Mol");
        subjects.add(s);

        s = new Subject("Inżynieria Oprogramowania(lab)", "mgr inż. Marek Ożarowski");
        subjects.add(s);

        s = new Subject("Proseminarium Inżynierskie", "mgr Natalia Patan-Trawka");
        subjects.add(s);

        s = new Subject("Systemy kontroli błędów i wersji", "mgr inż Wojciech Skwierawski");
        subjects.add(s);

        s = new Subject("Cyberterroryzm", "dr Ernest Lichocki");
        subjects.add(s);

        s = new Subject("Sztuczna Inteligencja", "dr Paweł Weichbroth");
        subjects.add(s);

        s = new Subject("Sztuczna Inteligencja(lab)", "mgr Kamil Łepek");
        subjects.add(s);

        s = new Subject("ZPAM", "mgr inż Dominik Tyniw");
        subjects.add(s);


        return subjects;
    }
}
