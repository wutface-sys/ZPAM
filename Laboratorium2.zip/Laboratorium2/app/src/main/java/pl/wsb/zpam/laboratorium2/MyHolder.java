package pl.wsb.zpam.laboratorium2;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.CheckBox;

public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    TextView txtSub;
    TextView txtName;
    CheckBox chkBox;
    OnListItemClick itemClickListener;

    public MyHolder(@NonNull View itemView) {
        super(itemView);


        txtSub = itemView.findViewById(R.id.txtSub);
        txtName = itemView.findViewById(R.id.txtName);
        chkBox = itemView.findViewById(R.id.bxStar);

        chkBox.setOnClickListener(this);
    }

    public void setItemClickListener(OnListItemClick ic)
    {
        this.itemClickListener=ic;
    }

    @Override
    public void onClick(View v) {
        this.itemClickListener.onItemClick(v,getLayoutPosition());
    }
}

