package pl.wsb.zpam.laboratorium2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activity_extra extends AppCompatActivity {

    private TextView ex1, ex2, ex3, ex4;
    private Button btn;
    int v1;
    String v2;
    float v3;
    boolean v4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extra);

        ex1 = findViewById(R.id.txtV1);
        ex2 = findViewById(R.id.txtV2);
        ex3 = findViewById(R.id.txtV3);
        ex4 = findViewById(R.id.txtV4);
        btn = findViewById(R.id.btnRev);

        v1 = this.getIntent().getIntExtra("int", 0);
        v2 = this.getIntent().getStringExtra("str");
        v3 = this.getIntent().getFloatExtra("float", 0);
        v4 = this.getIntent().getBooleanExtra("bool", true);

        ex1.setText(Integer.toString(v1));
        ex2.setText(v2);
        ex3.setText(Float.toString(v3));
        ex4.setText(Boolean.toString(v4));

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                v1 = v1*-1;
                String reverse = "";
                for(int i = v2. length() - 1; i >= 0; i--) {
                    reverse = reverse + v2. charAt(i); }
                v2 = reverse;
                v3 = v3*-1;
                v4 = !v4;

                ex1.setText(Integer.toString(v1));
                ex2.setText(v2);
                ex3.setText(Float.toString(v3));
                ex4.setText(Boolean.toString(v4));
            }
        });
    }
}
